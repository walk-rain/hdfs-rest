package com.dhcc.sys_manager.entity.msg;

public class GetPathTotalSizeResponse {
    private String retCode;
    private String retMsg;
    private String totalSize;

    public GetPathTotalSizeResponse() {
    }

    public GetPathTotalSizeResponse(String retCode, String retMsg) {
        this.retCode = retCode;
        this.retMsg = retMsg;
    }

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getRetMsg() {
        return retMsg;
    }

    public void setRetMsg(String retMsg) {
        this.retMsg = retMsg;
    }

    public String getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(String totalSize) {
        this.totalSize = totalSize;
    }
}
