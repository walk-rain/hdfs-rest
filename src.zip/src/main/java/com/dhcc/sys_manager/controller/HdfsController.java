package com.dhcc.sys_manager.controller;

import com.dhcc.sys_manager.entity.msg.GetPathTotalSizeResponse;
import com.dhcc.sys_manager.service.HdfsService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/hdfs-rest/v1.0/")
public class HdfsController {

    private HdfsService service;

    public HdfsController(HdfsService service) {
        this.service = service;
    }

    @RequestMapping(value = "/getHtmlSize")
    public GetPathTotalSizeResponse getHtmlSize() {
        return service.getHtmlSize();
    }
}
