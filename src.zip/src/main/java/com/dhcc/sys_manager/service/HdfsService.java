package com.dhcc.sys_manager.service;

import com.dhcc.sys_manager.entity.msg.GetPathTotalSizeResponse;

public interface HdfsService {
    public GetPathTotalSizeResponse getHtmlSize();
}
