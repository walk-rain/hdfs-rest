package com.dhcc.sys_manager.service.impl;

import com.dhcc.sys_manager.common.HdfsException;
import com.dhcc.sys_manager.entity.msg.GetPathTotalSizeResponse;
import com.dhcc.sys_manager.dao.HdfsRepository;
import com.dhcc.sys_manager.service.HdfsService;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service("HdfsService")
public class HdfsServiceImpl implements HdfsService {

    private HdfsRepository repository;

    public HdfsServiceImpl(HdfsRepository repository) {
        this.repository = repository;
    }

    @Override
    public GetPathTotalSizeResponse getHtmlSize() {
        GetPathTotalSizeResponse response = new GetPathTotalSizeResponse();
        try {
            String size = repository.getHTMLSize("/hbase/data/base_db");
            response.setRetCode("0");
            response.setRetMsg("Get size success.");
            response.setTotalSize(size);
        } catch (HdfsException e) {
            response.setRetCode("-1");
            response.setRetMsg(e.getMessage());
            response.setTotalSize("56.0GB");
        } catch (IOException e) {
            response.setRetCode("-1");
            response.setRetMsg("Build instance failed.");
            response.setTotalSize("56.0GB");
        }
        return response;
    }
}
