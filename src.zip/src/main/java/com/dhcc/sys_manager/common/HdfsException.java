package com.dhcc.sys_manager.common;

public class HdfsException extends Exception {
    public HdfsException() {}
    public HdfsException(String msg) { super(msg); }
}
